#include <stdio.h>

int main()
{
    float base, altura;
    printf("Intreduce la base del rectangulo: ");
    scanf("%f", &base); 

    printf("Intreduce la altura del rectangulo: ");
    scanf("%f", &altura); 

    float area= base*altura; 

    printf("el area del rectangulo de base %.2f y de altura %.2f es de %.2f", base, altura, area);

    return 0;
}