#include <stdio.h>

int main()
{
    int precio_base, kilometros;
    float consumo, precio_final;
    printf("Intreduce el precio del vehiculo: ");
    scanf("%d", &precio_base); 

    printf("Intreduce los kilometros: ");
    scanf("%d", &kilometros); 

    printf("Intreduce el consumo: ");
    scanf("%d", &consumo); 

    if (kilometros<20000 && consumo <=5)
    {
        precio_final=precio_base*1.2;
    }
    else if (kilometros>20000 && consumo <=5)
    {
        precio_final=precio_base*1.1;
    }
    else if (consumo > 5)
    {
        precio_final=precio_base*1.05;
    }
    
    printf("El precio final es igual a : %.2f", precio_final);
    
}