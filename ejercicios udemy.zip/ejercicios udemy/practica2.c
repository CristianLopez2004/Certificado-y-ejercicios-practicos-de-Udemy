#include <stdio.h>

int main()
{
    char c1,c2,c3;
    printf("Intreduce 3 caraceteres: ");
    scanf(" %c %c %c", &c1,&c2,&c3); 

    printf("%c-%c-%c",c1,c2,c3);

    return 0;
}