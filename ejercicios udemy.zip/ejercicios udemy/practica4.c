#include <stdio.h>

int main()
{
    float euros;
    printf("Intreduce los euros que quieres convertir: ");
    scanf("%f", &euros); 

    printf("el cambio de euros %.2f equivalen a  %.2f pesetas :", euros, euros*166.386);

    return 0;
}