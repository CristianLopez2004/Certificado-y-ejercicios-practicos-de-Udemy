#include <stdio.h>

int main()
{
    int nota;
    printf("Intreduce la nota del alumno: ");
    scanf("%d", &nota); 

    if (nota<=5)
    {
        printf("suspenso");
    }
    else if (nota == 6)
    {
        printf("bien");
    }
    else if (nota == 7 || nota == 8)
    {
        printf("Notable");
    }
    else if (nota == 9 || nota == 10)
    {
        printf("Sobresaliente");
    }
    else 
    {
        printf("Nota no valida");
    }


    return 0;
}