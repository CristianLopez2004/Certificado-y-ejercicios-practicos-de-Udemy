#include <stdio.h>

int main()
{
    float vector[10]= {1,7,5,-9,0,1,2,4,9,10};
    float maximo=vector[0];
    float minimo=vector[0];


    for (int i = 1; i < 10; i++)
    {
        if (vector[i]>maximo)
        {
            maximo=vector[i];
        }
        if (vector[i]>minimo)
        {
            minimo=vector[i];
        }
        
    }

    printf("Valor minimo: %d, Valor maximo : %d", minimo, maximo);

}